public class TextNote extends Note {

    public TextNote(String title, String content) {
        super(title, content);
    }

    @Override
    public void display() {
        System.out.println("Text Note:\n" + title + "\n" + content);
    }
}