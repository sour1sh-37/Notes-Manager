import java.util.*;

public class Main {
    public static void main(String[] args) {

        List<Note> notes = NotesLoader.loadNotes("../notes");

        new NotesGUI(notes);
    }
}