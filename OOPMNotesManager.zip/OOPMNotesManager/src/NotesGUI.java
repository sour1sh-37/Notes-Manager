import java.awt.*;
import java.util.List;
import javax.swing.*;

public class NotesGUI {

    private JFrame frame;
    private JList<String> topicList;
    private JTextArea contentArea;
    private DefaultListModel<String> listModel;
    private List<Note> notes;

    public NotesGUI(List<Note> notes) {
        this.notes = notes;
        initialize();
    }

    private void initialize() {

        // ===== FRAME =====
        frame = new JFrame("OOPM Notes Manager");
        frame.setSize(900, 550);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());
        frame.getContentPane().setBackground(new Color(244, 246, 247));

        // ===== LEFT PANEL (TOPICS) =====
        listModel = new DefaultListModel<>();
        for (Note n : notes) {
            listModel.addElement(n.getTitle());
        }

        topicList = new JList<>(listModel);
        topicList.setFont(new Font("Segoe UI", Font.BOLD, 14));
        topicList.setBackground(new Color(214, 234, 248));
        topicList.setForeground(new Color(44, 62, 80));
        topicList.setSelectionBackground(new Color(52, 152, 219));
        topicList.setSelectionForeground(Color.WHITE);

        JScrollPane listScroll = new JScrollPane(topicList);
        listScroll.setBorder(BorderFactory.createTitledBorder("Topics"));

        // ===== RIGHT PANEL (CONTENT) =====
        contentArea = new JTextArea();
        contentArea.setEditable(false);
        contentArea.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        contentArea.setLineWrap(true);
        contentArea.setWrapStyleWord(true);
        contentArea.setMargin(new Insets(10, 10, 10, 10));
        contentArea.setBackground(Color.WHITE);
        contentArea.setForeground(new Color(44, 62, 80));
        contentArea.setCaretColor(new Color(52, 152, 219));

        JScrollPane contentScroll = new JScrollPane(contentArea);
        contentScroll.setBorder(BorderFactory.createTitledBorder("Notes"));

        // ===== SPLIT PANE =====
        JSplitPane splitPane = new JSplitPane(
                JSplitPane.HORIZONTAL_SPLIT,
                listScroll,
                contentScroll
        );
        splitPane.setDividerLocation(250);

        frame.add(splitPane, BorderLayout.CENTER);

        // ===== TOP PANEL (SEARCH) =====
        JTextField searchField = new JTextField(20);
        JButton searchButton = new JButton("Search");

        JPanel topPanel = new JPanel();
        topPanel.setBackground(new Color(214, 234, 248));

        JLabel searchLabel = new JLabel("Search:");
        searchLabel.setForeground(new Color(44, 62, 80));

        searchButton.setBackground(new Color(52, 152, 219));
        searchButton.setForeground(Color.WHITE);
        searchButton.setFocusPainted(false);

        topPanel.add(searchLabel);
        topPanel.add(searchField);
        topPanel.add(searchButton);

        frame.add(topPanel, BorderLayout.NORTH);

        // ===== BOTTOM PANEL (PRINT BUTTON) =====
        JButton printButton = new JButton("Print");

        printButton.setBackground(new Color(52, 152, 219));
        printButton.setForeground(Color.WHITE);
        printButton.setFocusPainted(false);

        JPanel bottomPanel = new JPanel();
        bottomPanel.setBackground(new Color(214, 234, 248));
        bottomPanel.add(printButton);

        frame.add(bottomPanel, BorderLayout.SOUTH);

        // ===== EVENTS =====

        // Topic click
        topicList.addListSelectionListener(e -> {
            int index = topicList.getSelectedIndex();
            if (index >= 0) {
                contentArea.setText(notes.get(index).getContent());
            }
        });

        // Print
        printButton.addActionListener(e -> {
            try {
                contentArea.print(null, null, true, null, null, true);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        // Search
        searchButton.addActionListener(e -> {
            String keyword = searchField.getText().toLowerCase();

            for (int i = 0; i < notes.size(); i++) {
                if (notes.get(i).getTitle().toLowerCase().contains(keyword)) {
                    topicList.setSelectedIndex(i);
                    break;
                }
            }
        });

        frame.setVisible(true);
    }
}