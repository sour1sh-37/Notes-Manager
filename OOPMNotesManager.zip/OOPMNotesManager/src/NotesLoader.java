import java.io.*;
import java.util.*;

public class NotesLoader {

    public static List<Note> loadNotes(String folderPath) {
        List<Note> notes = new ArrayList<>();

        File folder = new File(folderPath);
        File[] files = folder.listFiles();

        if (files == null) return notes;

        for (File file : files) {
            if (file.isFile() && file.getName().endsWith(".txt")) {
                try (BufferedReader br = new BufferedReader(new FileReader(file))) {

                    String firstLine = br.readLine(); // TITLE: something
                    String title = firstLine.replace("TITLE:", "").trim();

                    String line;
                    StringBuilder content = new StringBuilder();

                    while ((line = br.readLine()) != null) {
                        if (!line.startsWith("CONTENT:")) {
                            content.append(line).append("\n");
                        }
                    }

                    notes.add(new TextNote(title, content.toString()));

                } catch (Exception e) {
                    System.out.println("Error reading: " + file.getName());
                }
            }
        }

        return notes;
    }
}