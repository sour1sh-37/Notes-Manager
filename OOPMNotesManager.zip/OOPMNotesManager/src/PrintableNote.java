import javax.swing.*;

public class PrintableNote extends Note {

    public PrintableNote(String title, String content) {
        super(title, content);
    }

    public void printNote(JTextArea textArea) {
        try {
            textArea.print();
        } catch (Exception e) {
            System.out.println("Printing failed");
        }
    }
}